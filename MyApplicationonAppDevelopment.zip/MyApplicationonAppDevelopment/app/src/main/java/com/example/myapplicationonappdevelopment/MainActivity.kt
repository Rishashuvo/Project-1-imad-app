package com.example.myapplicationonappdevelopment

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private val phrases = arrayOf(
        "Priyanka Chopra 41 years  Priyanka Chopra Jonas (pronounced [pɾɪˈjəŋka ˈtʃoːpɽa]; née Chopra; born 18 July 1982) is an Indian actress and producer. The winner of the Miss World 2000 pageant, Chopra is one of India's highest-paid actresses and has received numerous accolades, including two National Film Awards and five Filmfare Awards.  " ,
         "Amitabh Bachchan 81 years old Bachchan has worked as a playback singer, film producer, and television presenter. He has hosted several seasons of the game show Kaun Banega Crorepati, India's version of the game show franchise, Who Wants to Be a Millionaire?. He also entered politics for a time in the 1980s. " +
                 "Rajinikanth 73 years old Shivaji Rao Gaikwad, known professionally as Rajinikanth, is an Indian actor who works mainly in Tamil cinema. In a career spanning over five decades, he has done 169 films that includes films in Tamil, Hindi, Telugu, Kannada, Bengali, and Malayalam.",
        "Lata Mangeshkar 92 years old indian playback singer died in 2022 she is considered to be one of the greatest and most influential singers of the Indian subcontinent. Her voice was one of the unifying elements of the people of India, Pakistan, Bangladesh and Nepal " +
                "Mahatma Gandhi 78 years old Mohandas Karamchand Gandhi was an Indian lawyer, anti-colonial nationalist and political ethicist who employed nonviolent resistance to lead the successful campaign for India's independence from British rule. He inspired movements for civil rights and freedom across the world.",
        "Mukesh ambani 63 years old Mukesh Dhirubhai Ambani is an Indian businessman and the chairman and managing director of Reliance Industries. With an estimated net worth of \$113.7 billion as of March 2024, he is the richest person in Asia and 11th richest in the world",
        "Kalpana Chawla 40 years old  was an Indian-born American astronaut and aerospace engineer who was the first woman of Indian origin to fly to space. She first flew on Space Shuttle Columbia in 1997 as a mission specialist and primary robotic arm operator aboard STS-87",
        "Mother Teresa 87 years old was an Albanian-Indian Catholic nun and the founder of the Missionaries of Charity. Born in Skopje, then part of the Ottoman Empire, at the age of 18 she moved to Ireland and later to India, where she lived most of her life ",
        "Narendra Damodardas Mod 73 years old  an Indian politician who is serving as the 14th Prime Minister of India since May 2014. Modi was the Chief Minister of Gujarat from 2001 to 2014 and is the Member of Parliament for Varanasi.",
        "Shah Rukh Khan 58 years old also known by the initialism SRK, is an Indian actor and film producer who works in Hindi films. Referred to in the media as the \"Baadshah of Bollywood\" and \"King Khan\", he has appeared in more than 100 films, and earned numerous accolades, including 14 Filmfare Awards. "


    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val textView: TextView = findViewById(R.id.textView)
        val button: Button = findViewById(R.id.button)

        button.setOnClickListener {
            val randomIndex = Random.nextInt(phrases.size)
            textView.text = phrases[randomIndex]
        }
    }
}